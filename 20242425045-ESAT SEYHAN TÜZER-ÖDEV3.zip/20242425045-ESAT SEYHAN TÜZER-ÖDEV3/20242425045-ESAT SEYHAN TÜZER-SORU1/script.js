let urunSayisi = Number(prompt("Kaç farklı ürün gireceksiniz?"));
let sepetToplam = 0;
for (let i = 1; i <= urunSayisi; i++) {
    let urunAdi = prompt(i + ". ürün adı:");
    let fiyat = Number(prompt("Ürün fiyatı:"));
    while (fiyat < 0 || isNaN(fiyat)) {
        fiyat = Number(prompt("Hatalı giriş! Fiyat 0'dan küçük olamaz. Tekrar giriniz:"));
    }
    let adet = Number(prompt("Ürün adedi:"));
    while (adet < 1 || isNaN(adet)) {
        adet = Number(prompt("Hatalı giriş! Adet 1'den küçük olamaz. Tekrar giriniz:"));
    }
    let urunToplam = fiyat * adet;
    sepetToplam += urunToplam;
    document.write(`Fiyatı ${fiyat} TL olan ${urunAdi}'dan ${adet} adet alındı.<br>`);
    document.write(`Toplam bedel: ${urunToplam} TL <br><br>`);
}
let indirimliToplam = sepetToplam;
if (sepetToplam >= 1000) {
    indirimliToplam = sepetToplam * 0.9;
} else if (sepetToplam >= 500) {
    indirimliToplam = sepetToplam * 0.95;
}
document.write(`<hr>Sepet Toplamı: ${sepetToplam} TL <br>`);
document.write(`İndirimli Toplam: ${indirimliToplam} TL`);