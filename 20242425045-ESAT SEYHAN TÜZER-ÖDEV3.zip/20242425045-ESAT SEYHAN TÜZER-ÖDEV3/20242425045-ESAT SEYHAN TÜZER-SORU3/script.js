let a = 0;
let b = 1;
let i = 1;
document.write("Fibonacci Serisi:<br>");
while (i <= 20) {
    document.write(a + "<br>");
    let temp = a + b;
    a = b;
    b = temp;
    i++;
}