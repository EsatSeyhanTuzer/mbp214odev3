let kategoriler = ["Aksiyon", "Komedi", "Bilim Kurgu"];
let container = document.getElementById("container");
for (let i = 0; i < kategoriler.length; i++) {
    let kategoriDiv = document.createElement("div");
    kategoriDiv.className = "category";
    let baslik = document.createElement("h2");
    baslik.innerText = kategoriler[i];
    let filmDiv = document.createElement("div");
    filmDiv.className = "movies";
    for (let j = 1; j <= 5; j++) {
        let card = document.createElement("div");
        card.className = "card";
        card.innerText = "Film " + j;
        filmDiv.appendChild(card);
    }
    kategoriDiv.appendChild(baslik);
    kategoriDiv.appendChild(filmDiv);
    container.appendChild(kategoriDiv);
}